# api id, hash
API_ID = 20451323
API_HASH = 'afd5c31c4f19107ff7e3a6461a647eb2'

DELAYS = {
    'ACCOUNT': [5, 15],  # задержка между подключениями к аккаунтам (чем больше аккаунтов, тем больше задержка)
    'PLAY': [5, 15],   # задержка между запуском в секундах
    'ERROR_PLAY': [60, 180],    # задержка между ошибками в игре в секундах
}

# очков с каждой игры; максимум 280
POINTS = [240, 280]

# title blacklist tasks (do not change)
BLACKLIST_TASKS = ['Farm points']

# session folder (do not change)
WORKDIR = "sessions/"


